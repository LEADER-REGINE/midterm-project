const theme = (isDarkMode) => ({
  mode: isDarkMode ? "dark" : "light",

  
  
});

export default theme;