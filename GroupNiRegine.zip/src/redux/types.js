export const SET_THEME = "SET_THEME";
export const USER_ID = "USER_ID";